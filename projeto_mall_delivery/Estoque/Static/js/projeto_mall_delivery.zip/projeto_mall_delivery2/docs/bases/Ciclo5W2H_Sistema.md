## Plano de Ação 5W2H - Sistema - Mall Delivery

### Who

#### (Quem -> Sistema) - Quem vai fazer o sistema e para quem é o sistema ? 
 O sistema será feito pela equipe de desenvolvimento, que será destinado para a empresa Mall Delivery

### When 

#### (Quando -> Sistema) - Quando o sistema vai ficar pronto?

As datas de atualização serão semanais, e terão apresentações maiores nos dias das provas AP1 e AP2.

### Where 
#### (Onde -> Sistema) - Onde será feito o sistema?
O sistema será feito num Ambiente de Desenvolvimento Integrado (IDE) que suporte a linguagem Python .

### What 
#### (O que -> Sistema) - O que é o sistema? O que precisa ser feito? -> Quais são os requisitos feitos pelo cliente?
Se trata de criar um sistema de cadastro e integrar uma API com os demais sistemas que formam o ecossistema da plataforma. 
Os sistemas são: Loja, Logística e Recebimentos.  

### Why 
#### (Por que -> Sistema) - Porque esse sistema é necessário? -> No que ele vai ajudar o cliente?
O sistema irá melhorar a integração plataforma-loja, para que não haja conflitos de produtos nos estoques, sistemas e outros recursos.


### How 
#### (Como -> Sistema) - Como será feito o sistema?
O sistema será feito a partir de reuniões da equipe durante e fora das aulas, documentando o que for necessário para realização do sistema, e após isso, haverá a parte de programação, utilizando a linguagem python com o framework Django.

### How much 
#### (Preço -> Sistema) - Quanto será gasto no sistema? : 
O custo desse sistema não é monetário, e sim em relação ao tempo que será gasto para a conclusão da tarefa.

