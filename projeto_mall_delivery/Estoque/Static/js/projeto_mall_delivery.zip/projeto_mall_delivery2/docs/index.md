# Home

**Número do Grupo**: 23<br>
**Código da Disciplina**: FGA0208-T01<br>

## Alunos
|Matrícula | Aluno |
| -- | -- |
| 202307164641 | Gabriel Mendes |
| 202301135265 | Thiago Corrêa Brandão |
| 202307164534 |  João Pedro Menezes |
| 202202101036 |  Breno França |
| 202307164551 |  Douglas Hancock |

## Sobre 
Descreva o seu projeto em linhas gerais. 

## Screenshots
Adicione 3 ou mais screenshots do projeto em termos de interface e funcionamento.

## Instalação

- **Linguagens**: Python  
- **Tecnologias**: Django  

Descreva os pré-requisitos para rodar o seu projeto e os comandos necessários. Insira um manual ou um script para auxiliar ainda mais.

## Uso 
----------------------------------------------------------------------------------------------------------

## Vídeo
----------------------------------------------------------------------------------------------------------

## Outros 
----------------------------------------------------------------------------------------------------------
