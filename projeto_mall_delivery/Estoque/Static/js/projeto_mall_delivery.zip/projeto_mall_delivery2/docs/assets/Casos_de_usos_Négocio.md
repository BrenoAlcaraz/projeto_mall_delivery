## **Casos de Uso:**

**Caso de uso:** Receber solicitação de entrada no app

**Interesses:**
- Négocio: Deseja receber solicitação de alguma loja para entrada no sistema.

**Caso de uso:** Analisar loja

**Interesses:**
- Négocio: Deseja após o recebimento do pedido de ingresso de alguma loja no sistema , analisar com mais profundidade o pedido e a loja.

**Caso de uso:** Aceitar loja

**Interesses:**
- Négocio: Deseja após concluida a análise da loja que requiriu entrada no sistema , aceitar a entrada da mesma.

**Caso de uso:** Recusar loja

**Interesses:**
- Négocio: Deseja após concluida a análise da loja que requiriu entrada no sistema , recusar a entrada da mesma.

**Caso de uso:** Integrar os métodos de pagamento da loja aceita com os do sistema

**Interesses:**
- Négocio: Deseja após concluida a entrada de alguma loja no sistema, integrar os métodos de pagamento.

**Caso de uso:** Integrar os estoques da loja com o sistema

**Interesses:**
- Négocio: Deseja após concluida a análise da loja que requiriu entrada no sistema , recusar a entrada da mesma.
