
# Lojista

## **_Caso de uso:_** Fazer cadastro 

**Descrição:**
- Usuário: Lojista deseja realizar o cadastro das informações necessárias pra ingressar no sistema.

## **_Caso de uso:_** Fazer login

**Descrição:**
- Usuário: Lojista deseja entrar no sistema.

## **_Caso de uso:_** Fazer Logout

**Descrição:**
- Usuário: Lojista deseja sair do sistema.

## **_Caso de uso:_** Cadastrar Loja

**Descrição:**
- Usuário: Lojista deseja cadastrar as lojas no sistema. 

## **_Caso de uso:_** Adicionar Produto
**Descrição:**
- Usuário: Lojista deseja adicionar produto ao estoque.

## **_Caso de uso:_** Remover Produto
**Descrição:**
- Usuário: Lojista deseja remover produto do estoque.

# Consumidor

## **_Caso de uso:_** Fazer Cadastro

**Descrição:**
- Usuário:  Consumidor deseja realizar o cadastro das informações necessárias pra ingressar no sistema.

## **_Caso de uso:_** Fazer login

**Descrição:**
- Usuário: Consumidor deseja entrar no sistema.

## **_Caso de uso:_** Fazer Logout

**Descrição:**
- Usuário: Consumidor deseja sair do sistema.
  

# Administrador

## **_Caso de uso:_** Fazer cadastro 

**Descrição:**
- Usuário: Administrador deseja realizar o cadastro das informações necessárias pra ingressar no sistema.

## **_Caso de uso:_** Fazer login

**Descrição:**
- Usuário: Administrador deseja entrar no sistema.

## **_Caso de uso:_** Fazer Logout

**Descrição:**
- Usuário: Administrador deseja sair do sistema.

## **_Caso de uso:_** Validar cadastro

**Descrição:**
- Usuário: Administrador deseja validar o cadastro do lojista do sistema.

## **_Caso de uso:_** Validar loja

**Descrição:**
- Usuário: Administrador deseja validar as lojas cadastradas pelo lojista no sistema.

  
