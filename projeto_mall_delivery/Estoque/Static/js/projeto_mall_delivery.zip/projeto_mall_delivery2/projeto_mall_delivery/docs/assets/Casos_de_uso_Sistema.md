
# Lojista

## **_Caso de uso:_** Fazer login

**Descrição:**
- Usuário: Deseja entrar no sistema.

## **_Caso de uso:_** Fazer cadastro

**Descrição:**
- Usuário: Deseja cadastrar a loja no sistema.

## **_Caso de uso:_** Adicionar estoque

**Descrição:**
- Usuário: Deseja adicionar produtos ao estoque da loja.

# Administrador

## **_Caso de uso:_** Validar cadastro

**Descrição:**
- Usuário: Validar o cadastro das lojas do sistema.
