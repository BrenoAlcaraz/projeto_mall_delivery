from django.shortcuts import render, redirect
from . forms import CreateConsumidorForm,CreateLojistaForm

#fç pagina principal
def homepage(request):
    return render(request,'reg_auth_app/index.html')

#fç de registro consumidor
def cadastro_consumidor(request):

    form = CreateConsumidorForm()

    if request.method == 'POST':
        form = CreateConsumidorForm(request.POST)

        if form.is_valid():

            form.save()

            return redirect('login')
        

    context = {'form_cadastro_consumidor':form}

    return render(request,'reg_auth_app/cadastro_consumidor.html',context=context)

#fç de registro lojista
def cadastro_lojista(request):

    form = CreateLojistaForm()

    if request.method == 'POST':
        form = CreateLojistaForm(request.POST or None)

        if form.is_valid():

            form.save()

            return redirect('login')
        
    context = {'form_cadastro_lojista':form}
        
    return render(request,'reg_auth_app/cadastro_lojista.html',context=context)

#fç pagina de login
def login(request):
    return render(request,'reg_auth_app/login.html')

#fç pagina de escolha de usuario
def escolha_user(request):
    return render(request,'reg_auth_app/escolha_user.html')
