from django.apps import AppConfig


class RegAuthAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reg_auth_app'
